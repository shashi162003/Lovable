package com.devshashi.distributed_lovable.config_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
