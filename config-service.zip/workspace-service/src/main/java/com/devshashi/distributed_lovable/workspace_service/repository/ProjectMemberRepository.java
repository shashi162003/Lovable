package com.devshashi.distributed_lovable.workspace_service.repository;

import com.devshashi.distributed_lovable.common_lib.enums.ProjectRole;
import com.devshashi.distributed_lovable.workspace_service.entity.ProjectMember;
import com.devshashi.distributed_lovable.workspace_service.entity.ProjectMemberId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProjectMemberRepository extends JpaRepository<ProjectMember, ProjectMemberId> {

    List<ProjectMember> findByIdProjectId(Long projectId);

    @Query("""
        SELECT pm.projectRole
        FROM ProjectMember pm
        WHERE pm.id.projectId = :projectId
        AND pm.id.userId = :userId
    """)
    Optional<ProjectRole> findRoleByProjectIdAndUserId(@Param("projectId") Long projectId,
                                                       @Param("userId") Long userId);

    @Query("""
        SELECT COUNT(pm)
        FROM ProjectMember pm
        WHERE pm.id.userId = :userId
        AND pm.projectRole = 'OWNER'
    """)
    int countProjectOwnedByUser(@Param("userId") Long userId);
}
